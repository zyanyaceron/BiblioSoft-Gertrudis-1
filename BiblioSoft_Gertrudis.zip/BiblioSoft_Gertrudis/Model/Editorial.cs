﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiblioSoft_Gertrudis.Model
{
    public class Editorial
    {
        private int id;
        private string nombre;
        private string pais;

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Pais { get => pais; set => pais = value; }

        public Editorial() { }
    }
}
