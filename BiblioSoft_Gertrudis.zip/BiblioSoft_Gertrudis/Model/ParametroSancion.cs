﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiblioSoft_Gertrudis.Model
{
    public class ParametroSancion
    {
        private int id;
        private int dias;
        private DateTime fecRegreso; // Corresponde a FEC_REGRESO DATE en tu MER
        private int montoDiario;

        public int Id { get => id; set => id = value; }
        public int Dias { get => dias; set => dias = value; }
        public DateTime FecRegreso { get => fecRegreso; set => fecRegreso = value; }
        public int MontoDiario { get => montoDiario; set => montoDiario = value; }

        public ParametroSancion() { }
    }
}
