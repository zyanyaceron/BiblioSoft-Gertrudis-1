﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiblioSoft_Gertrudis.Model
{
    public class Usuario
    {
       
        private string ine_dni;
        private string nombre;
        private string apellidoP;
        private string apellidoM;
        private string tel;
        private string email;

        public string Ine_dni { get => ine_dni; set => ine_dni = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string ApellidoP { get => apellidoP; set => apellidoP = value; }
        public string ApellidoM { get => apellidoM; set => apellidoM = value; }
        public string Tel { get => tel; set => tel = value; }
        public string Email { get => email; set => email = value; }

        
        public Usuario() { }
    }
}
