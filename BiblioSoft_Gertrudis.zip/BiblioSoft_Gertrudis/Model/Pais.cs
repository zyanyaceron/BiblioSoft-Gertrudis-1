﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiblioSoft_Gertrudis.Model
{
    internal class Pais
    {
    }
}
