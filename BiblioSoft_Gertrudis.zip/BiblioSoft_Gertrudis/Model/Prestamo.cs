﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiblioSoft_Gertrudis.Model
{
    public class Prestamo
    {
        private int id;
        private DateTime fecSalida;
        private DateTime fecRegreso;

        private Usuario usuario;
        private Libro libro;

       

        public int Id { get => id; set => id = value; }
        public DateTime FecSalida { get => fecSalida; set => fecSalida = value; }
        public DateTime FecRegreso { get => fecRegreso; set => fecRegreso = value; }
        public Usuario Usuario { get => usuario; set => usuario = value; }
        public Libro Libro { get => libro; set => libro = value; }
        

        public Prestamo() { }
    }

}
