﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiblioSoft_Gertrudis.Model
{
    public class SancionxPrestamo
    {
        // Esta clase solo existe si hay una relación real.
        // Si no hay sanción, simplemente no se instancia este objeto.
        private Sancion sancion;
        private Prestamo prestamo;

        public Sancion Sancion { get => sancion; set => sancion = value; }
        public Prestamo Prestamo { get => prestamo; set => prestamo = value; }

        public SancionxPrestamo() { }
    }
}
