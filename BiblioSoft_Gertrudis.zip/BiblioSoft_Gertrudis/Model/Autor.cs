﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiblioSoft_Gertrudis.Model
{
    namespace BiblioSoft_Gertrudis.Model
    {
        public class Autor
        {
            // Atributos privados
            private int id;
            private string nombre;
            private string apellidoP;
            private string apellidoM;
            private string nacionalidad;

            // Encapsulamiento (Getters y Setters)
            public int Id { get => id; set => id = value; }
            public string Nombre { get => nombre; set => nombre = value; }
            public string ApellidoP { get => apellidoP; set => apellidoP = value; }
            public string ApellidoM { get => apellidoM; set => apellidoM = value; }
            public string Nacionalidad { get => nacionalidad; set => nacionalidad = value; }

            // Constructor vacío
            public Autor() { }
        }
    }
}
