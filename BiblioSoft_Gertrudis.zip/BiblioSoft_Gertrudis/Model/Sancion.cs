﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiblioSoft_Gertrudis.Model
{
    public class Sancion
    {
        private int id;
        private int diasRetraso;
        private int monto;

        // COMPOSICIÓN: Relación con el parámetro (FK_ID_PARAMETRO)
        private ParametroSancion parametro;

        public int Id { get => id; set => id = value; }
        public int DiasRetraso { get => diasRetraso; set => diasRetraso = value; }
        public int Monto { get => monto; set => monto = value; }
        public ParametroSancion Parametro { get => parametro; set => parametro = value; }

        public Sancion() { }
    }
}
