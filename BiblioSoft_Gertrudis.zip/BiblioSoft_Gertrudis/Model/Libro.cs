﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiblioSoft_Gertrudis.Model
{
    public class Libro
    {
        // 1. Atributos privados
        private string isbn;
        private string titulo;
        private DateTime anioPublicacion;
        private string estadoFisico;
        private string estado;

        // COMPOSICIÓN: En lugar de "int id_categoria", usamos el objeto completo
        private Categoria categoria;
        private Editorial editorial;

        // 2. Encapsulamiento (Getters y Setters)
        public string Isbn { get => isbn; set => isbn = value; }
        public string Titulo { get => titulo; set => titulo = value; }
        public DateTime AnioPublicacion { get => anioPublicacion; set => anioPublicacion = value; }
        public string EstadoFisico { get => estadoFisico; set => estadoFisico = value; }
        public string Estado { get => estado; set => estado = value; }

        
        public Categoria Categoria { get => categoria; set => categoria = value; }
        public Editorial Editorial { get => editorial; set => editorial = value; }

       
        public Libro()
        {
        }
    }
}
