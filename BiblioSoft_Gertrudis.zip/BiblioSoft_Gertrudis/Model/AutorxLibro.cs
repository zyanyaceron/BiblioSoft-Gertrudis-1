﻿using BiblioSoft_Gertrudis.Model.BiblioSoft_Gertrudis.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace BiblioSoft_Gertrudis.Model
{
    public class AutorxLibro
    {
        // En lugar de guardar solo IDs, guardamos los objetos completos
        private Autor autor;
        private Libro libro;

        public Autor Autor { get => autor; set => autor = value; }
        public Libro Libro { get => libro; set => libro = value; }

        public AutorxLibro() { }
    }
}
