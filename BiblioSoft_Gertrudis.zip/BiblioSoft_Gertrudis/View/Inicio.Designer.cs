﻿namespace BiblioSoft_Gertrudis.View
{
    partial class Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inicio));
            panel1 = new Panel();
            textISBN = new TextBox();
            txtNuevoLibro = new Button();
            button1 = new Button();
            btnPrestamos = new Button();
            button3 = new Button();
            btnReportes = new Button();
            button5 = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.ForeColor = Color.Chocolate;
            panel1.Location = new Point(202, 99);
            panel1.Name = "panel1";
            panel1.Size = new Size(889, 548);
            panel1.TabIndex = 0;
            panel1.Resize += panel1_Resize;
            // 
            // textISBN
            // 
            textISBN.BackColor = Color.Silver;
            textISBN.BorderStyle = BorderStyle.None;
            textISBN.Font = new Font("Georgia", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textISBN.ForeColor = Color.White;
            textISBN.Location = new Point(202, 40);
            textISBN.MaxLength = 17;
            textISBN.Name = "textISBN";
            textISBN.Size = new Size(600, 28);
            textISBN.TabIndex = 1;
            textISBN.Text = "Buscar por ISBN";
            textISBN.TextChanged += textBox1_TextChanged;
            textISBN.Enter += textISBN_Enter;
            textISBN.KeyPress += textISBN_KeyPress;
            textISBN.Leave += textISBN_Leave;
            textISBN.Validating += textISBN_Validating;
            // 
            // txtNuevoLibro
            // 
            txtNuevoLibro.BackColor = Color.FromArgb(192, 255, 192);
            txtNuevoLibro.Cursor = Cursors.Hand;
            txtNuevoLibro.FlatAppearance.BorderColor = Color.FromArgb(192, 255, 192);
            txtNuevoLibro.FlatAppearance.BorderSize = 0;
            txtNuevoLibro.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 255, 192);
            txtNuevoLibro.FlatAppearance.MouseOverBackColor = Color.White;
            txtNuevoLibro.FlatStyle = FlatStyle.Flat;
            txtNuevoLibro.Font = new Font("Mongolian Baiti", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            txtNuevoLibro.ForeColor = Color.Black;
            txtNuevoLibro.Location = new Point(940, 37);
            txtNuevoLibro.Name = "txtNuevoLibro";
            txtNuevoLibro.Size = new Size(151, 35);
            txtNuevoLibro.TabIndex = 2;
            txtNuevoLibro.Text = "NUEVO LIBRO";
            txtNuevoLibro.UseVisualStyleBackColor = false;
            txtNuevoLibro.Click += textBuscarISBN_Click;
            // 
            // button1
            // 
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.White;
            button1.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.Location = new Point(818, 28);
            button1.Name = "button1";
            button1.Size = new Size(55, 54);
            button1.TabIndex = 3;
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnPrestamos
            // 
            btnPrestamos.FlatAppearance.BorderSize = 0;
            btnPrestamos.FlatAppearance.MouseDownBackColor = Color.White;
            btnPrestamos.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnPrestamos.FlatStyle = FlatStyle.Flat;
            btnPrestamos.Font = new Font("Ink Free", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPrestamos.Image = (Image)resources.GetObject("btnPrestamos.Image");
            btnPrestamos.Location = new Point(2, 108);
            btnPrestamos.Name = "btnPrestamos";
            btnPrestamos.Size = new Size(194, 82);
            btnPrestamos.TabIndex = 4;
            btnPrestamos.Text = "Prestamos";
            btnPrestamos.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnPrestamos.UseVisualStyleBackColor = true;
            btnPrestamos.Click += btnPrestamos_Click;
            // 
            // button3
            // 
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseDownBackColor = Color.White;
            button3.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Ink Free", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(2, 218);
            button3.Name = "button3";
            button3.Size = new Size(183, 86);
            button3.TabIndex = 5;
            button3.Text = "Usuario";
            button3.TextImageRelation = TextImageRelation.ImageBeforeText;
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // btnReportes
            // 
            btnReportes.FlatAppearance.BorderSize = 0;
            btnReportes.FlatAppearance.MouseDownBackColor = Color.White;
            btnReportes.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Ink Free", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReportes.Image = (Image)resources.GetObject("btnReportes.Image");
            btnReportes.ImageAlign = ContentAlignment.MiddleLeft;
            btnReportes.Location = new Point(2, 336);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(194, 94);
            btnReportes.TabIndex = 6;
            btnReportes.Text = "Reportes";
            btnReportes.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnReportes.UseVisualStyleBackColor = true;
            btnReportes.Click += button4_Click;
            // 
            // button5
            // 
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.MouseDownBackColor = Color.White;
            button5.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Ink Free", 7.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.ImageAlign = ContentAlignment.MiddleLeft;
            button5.Location = new Point(2, 469);
            button5.Name = "button5";
            button5.Size = new Size(194, 78);
            button5.TabIndex = 7;
            button5.Text = "Configuracion";
            button5.TextImageRelation = TextImageRelation.ImageBeforeText;
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.ErrorImage = (Image)resources.GetObject("pictureBox1.ErrorImage");
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(55, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(80, 80);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // Inicio
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(1103, 659);
            Controls.Add(pictureBox1);
            Controls.Add(button5);
            Controls.Add(btnReportes);
            Controls.Add(button3);
            Controls.Add(btnPrestamos);
            Controls.Add(button1);
            Controls.Add(txtNuevoLibro);
            Controls.Add(textISBN);
            Controls.Add(panel1);
            Name = "Inicio";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Inicio";
            Load += Inicio_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private TextBox textISBN;
        private Button txtNuevoLibro;
        private Button button1;
        private Button btnPrestamos;
        private Button button3;
        private Button btnReportes;
        private Button button5;
        private PictureBox pictureBox1;
    }
}