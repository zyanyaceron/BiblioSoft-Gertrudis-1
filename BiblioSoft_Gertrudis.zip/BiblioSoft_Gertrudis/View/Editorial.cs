﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BiblioSoft_Gertrudis.View
{
    public partial class Editorial : Form
    {
        public Editorial()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(txtNombre.Text))
            {
                DialogResult resultado = MessageBox.Show("¿Seguro que quieres salir? Se perderán los datos no guardados.",
                                                       "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    this.Close();
                }
            }
            else
            {
                this.Close(); // Si está vacío, cerramos de inmediato
            }
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Solo permite letras y la tecla de borrar (BackSpace)
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true; // Bloquea la tecla
                MessageBox.Show("En este campo solo se permiten letras", "Aviso");
            }
        }
    }
}
