﻿namespace BiblioSoft_Gertrudis.View
{
    partial class PantallaReportes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PantallaReportes));
            panel1 = new Panel();
            button1 = new Button();
            btnCalendario = new Button();
            label2 = new Label();
            label1 = new Label();
            btnPrestamos = new Button();
            btnUsuario = new Button();
            btnReportes = new Button();
            btnConfig = new Button();
            btnRegresar = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(button1);
            panel1.Controls.Add(btnCalendario);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.ForeColor = Color.Black;
            panel1.Location = new Point(202, 99);
            panel1.Name = "panel1";
            panel1.Size = new Size(889, 548);
            panel1.TabIndex = 2;
            // 
            // button1
            // 
            button1.BackColor = Color.White;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.White;
            button1.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Ink Free", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.Location = new Point(365, 253);
            button1.Name = "button1";
            button1.Size = new Size(76, 82);
            button1.TabIndex = 14;
            button1.TextImageRelation = TextImageRelation.ImageBeforeText;
            button1.UseVisualStyleBackColor = false;
            // 
            // btnCalendario
            // 
            btnCalendario.BackColor = Color.White;
            btnCalendario.FlatAppearance.BorderSize = 0;
            btnCalendario.FlatAppearance.MouseDownBackColor = Color.White;
            btnCalendario.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnCalendario.FlatStyle = FlatStyle.Flat;
            btnCalendario.Font = new Font("Ink Free", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalendario.Image = (Image)resources.GetObject("btnCalendario.Image");
            btnCalendario.Location = new Point(308, 3);
            btnCalendario.Name = "btnCalendario";
            btnCalendario.Size = new Size(76, 82);
            btnCalendario.TabIndex = 13;
            btnCalendario.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnCalendario.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Red;
            label2.Font = new Font("Georgia", 16F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.Location = new Point(15, 268);
            label2.Name = "label2";
            label2.Size = new Size(344, 38);
            label2.TabIndex = 1;
            label2.Text = "USUARIOS MOROSOS";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.PaleGreen;
            label1.Font = new Font("Georgia", 16F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(15, 25);
            label1.Name = "label1";
            label1.Size = new Size(287, 38);
            label1.TabIndex = 0;
            label1.Text = "PRESTAMOS HOY";
            // 
            // btnPrestamos
            // 
            btnPrestamos.FlatAppearance.BorderSize = 0;
            btnPrestamos.FlatAppearance.MouseDownBackColor = Color.White;
            btnPrestamos.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnPrestamos.FlatStyle = FlatStyle.Flat;
            btnPrestamos.Font = new Font("Ink Free", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPrestamos.Image = (Image)resources.GetObject("btnPrestamos.Image");
            btnPrestamos.Location = new Point(2, 99);
            btnPrestamos.Name = "btnPrestamos";
            btnPrestamos.Size = new Size(194, 82);
            btnPrestamos.TabIndex = 6;
            btnPrestamos.Text = "Prestamos";
            btnPrestamos.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnPrestamos.UseVisualStyleBackColor = true;
            btnPrestamos.Click += btnPrestamos_Click;
            // 
            // btnUsuario
            // 
            btnUsuario.FlatAppearance.BorderSize = 0;
            btnUsuario.FlatAppearance.MouseDownBackColor = Color.White;
            btnUsuario.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnUsuario.FlatStyle = FlatStyle.Flat;
            btnUsuario.Font = new Font("Ink Free", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUsuario.Image = (Image)resources.GetObject("btnUsuario.Image");
            btnUsuario.ImageAlign = ContentAlignment.MiddleLeft;
            btnUsuario.Location = new Point(2, 218);
            btnUsuario.Name = "btnUsuario";
            btnUsuario.Size = new Size(183, 86);
            btnUsuario.TabIndex = 7;
            btnUsuario.Text = "Usuario";
            btnUsuario.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnUsuario.UseVisualStyleBackColor = true;
            btnUsuario.Click += btnUsuario_Click;
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.White;
            btnReportes.Enabled = false;
            btnReportes.FlatAppearance.BorderSize = 0;
            btnReportes.FlatAppearance.MouseDownBackColor = Color.White;
            btnReportes.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Ink Free", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReportes.Image = (Image)resources.GetObject("btnReportes.Image");
            btnReportes.ImageAlign = ContentAlignment.MiddleLeft;
            btnReportes.Location = new Point(2, 345);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(194, 94);
            btnReportes.TabIndex = 8;
            btnReportes.Text = "Reportes";
            btnReportes.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnReportes.UseVisualStyleBackColor = false;
            btnReportes.Click += btnReportes_Click;
            // 
            // btnConfig
            // 
            btnConfig.FlatAppearance.BorderSize = 0;
            btnConfig.FlatAppearance.MouseDownBackColor = Color.White;
            btnConfig.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnConfig.FlatStyle = FlatStyle.Flat;
            btnConfig.Font = new Font("Ink Free", 7.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnConfig.Image = (Image)resources.GetObject("btnConfig.Image");
            btnConfig.ImageAlign = ContentAlignment.MiddleLeft;
            btnConfig.Location = new Point(2, 470);
            btnConfig.Name = "btnConfig";
            btnConfig.Size = new Size(194, 78);
            btnConfig.TabIndex = 9;
            btnConfig.Text = "Configuracion";
            btnConfig.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnConfig.UseVisualStyleBackColor = true;
            btnConfig.Click += btnConfig_Click;
            // 
            // btnRegresar
            // 
            btnRegresar.FlatAppearance.BorderSize = 0;
            btnRegresar.FlatAppearance.MouseDownBackColor = Color.White;
            btnRegresar.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnRegresar.FlatStyle = FlatStyle.Flat;
            btnRegresar.Image = (Image)resources.GetObject("btnRegresar.Image");
            btnRegresar.Location = new Point(12, 12);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(55, 54);
            btnRegresar.TabIndex = 12;
            btnRegresar.UseVisualStyleBackColor = true;
            btnRegresar.Click += btnRegresar_Click;
            // 
            // PantallaReportes
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(1103, 659);
            Controls.Add(panel1);
            Controls.Add(btnRegresar);
            Controls.Add(btnConfig);
            Controls.Add(btnReportes);
            Controls.Add(btnUsuario);
            Controls.Add(btnPrestamos);
            Name = "PantallaReportes";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "PantallaReportes";
            FormClosed += PantallaReportes_FormClosed;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button btnPrestamos;
        private Button btnUsuario;
        private Button btnReportes;
        private Button btnConfig;
        private Button btnRegresar;
        private Label label1;
        private Button btnCalendario;
        private Label label2;
        private Button button1;
    }
}