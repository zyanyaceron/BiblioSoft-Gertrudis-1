﻿namespace BiblioSoft_Gertrudis.View
{
    partial class Autor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Autor));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtNombre = new TextBox();
            txtApellidoP = new TextBox();
            txtApellidoM = new TextBox();
            txtNacionalidad = new TextBox();
            btnRegresar = new Button();
            label5 = new Label();
            btnGuardar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(44, 102);
            label1.Name = "label1";
            label1.Size = new Size(78, 25);
            label1.TabIndex = 0;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(44, 162);
            label2.Name = "label2";
            label2.Size = new Size(143, 25);
            label2.TabIndex = 1;
            label2.Text = "Apellido Paterno";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(44, 235);
            label3.Name = "label3";
            label3.Size = new Size(150, 25);
            label3.TabIndex = 2;
            label3.Text = "Apellido Materno";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(44, 301);
            label4.Name = "label4";
            label4.Size = new Size(115, 25);
            label4.TabIndex = 3;
            label4.Text = "Nacionalidad";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(127, 102);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(186, 31);
            txtNombre.TabIndex = 4;
            txtNombre.TextChanged += txtNombre_TextChanged;
            txtNombre.KeyPress += ValidarSoloLetras;
            // 
            // txtApellidoP
            // 
            txtApellidoP.Location = new Point(193, 162);
            txtApellidoP.Name = "txtApellidoP";
            txtApellidoP.Size = new Size(186, 31);
            txtApellidoP.TabIndex = 5;
            txtApellidoP.KeyPress += ValidarSoloLetras;
            // 
            // txtApellidoM
            // 
            txtApellidoM.Location = new Point(193, 235);
            txtApellidoM.Name = "txtApellidoM";
            txtApellidoM.Size = new Size(186, 31);
            txtApellidoM.TabIndex = 6;
            txtApellidoM.KeyPress += ValidarSoloLetras;
            // 
            // txtNacionalidad
            // 
            txtNacionalidad.Location = new Point(193, 301);
            txtNacionalidad.Name = "txtNacionalidad";
            txtNacionalidad.Size = new Size(186, 31);
            txtNacionalidad.TabIndex = 7;
            txtNacionalidad.TextChanged += txtNacionalidad_TextChanged;
            txtNacionalidad.KeyPress += ValidarSoloLetras;
            // 
            // btnRegresar
            // 
            btnRegresar.FlatAppearance.BorderSize = 0;
            btnRegresar.FlatAppearance.MouseDownBackColor = Color.White;
            btnRegresar.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnRegresar.FlatStyle = FlatStyle.Flat;
            btnRegresar.Image = (Image)resources.GetObject("btnRegresar.Image");
            btnRegresar.Location = new Point(12, 12);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(55, 54);
            btnRegresar.TabIndex = 20;
            btnRegresar.UseVisualStyleBackColor = true;
            btnRegresar.Click += btnRegresar_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Trebuchet MS", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(85, 30);
            label5.Name = "label5";
            label5.Size = new Size(234, 36);
            label5.TabIndex = 21;
            label5.Text = "AGREGAR AUTOR";
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.Cursor = Cursors.Hand;
            btnGuardar.FlatAppearance.BorderColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.BorderSize = 0;
            btnGuardar.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.MouseOverBackColor = SystemColors.MenuHighlight;
            btnGuardar.FlatStyle = FlatStyle.Flat;
            btnGuardar.Font = new Font("Mongolian Baiti", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnGuardar.ForeColor = Color.Black;
            btnGuardar.Location = new Point(136, 368);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(126, 47);
            btnGuardar.TabIndex = 22;
            btnGuardar.Text = "GUARDAR ";
            btnGuardar.UseVisualStyleBackColor = false;
            // 
            // Autor
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(460, 450);
            Controls.Add(btnGuardar);
            Controls.Add(label5);
            Controls.Add(btnRegresar);
            Controls.Add(txtNacionalidad);
            Controls.Add(txtApellidoM);
            Controls.Add(txtApellidoP);
            Controls.Add(txtNombre);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Autor";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Autor";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtNombre;
        private TextBox txtApellidoP;
        private TextBox txtApellidoM;
        private TextBox txtNacionalidad;
        private Button btnRegresar;
        private Label label5;
        private Button btnGuardar;
    }
}