﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BiblioSoft_Gertrudis.View
{
    public partial class PantallaReportes : Form
    {
        public PantallaReportes()
        {
            InitializeComponent();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {

        }

        private void PantallaReportes_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Mata el proceso de BiblioSoft por completo al cerrar esta ventana
            Application.Exit();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Form inicio = Application.OpenForms["Inicio"];

            if (inicio != null)
            {
                inicio.Show(); // La volvemos a mostrar

                // IMPORTANTE: Aquí NO uses Application.Exit(), 
                // solo cierra esta ventana de Prestamos para volver a la anterior.
                this.Dispose();
            }
        }

        private void btnPrestamos_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaPrestamos pantallaPrestamos = new PantallaPrestamos();

            // Mostramos la nueva
            pantallaPrestamos.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void btnUsuario_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaUsuario pantallaUsuario = new PantallaUsuario();

            // Mostramos la nueva
            pantallaUsuario.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void btnConfig_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaConfiguracion PantallaConfiguracion = new PantallaConfiguracion();

            // Mostramos la nueva
            PantallaConfiguracion.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }
    }
}
