﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BiblioSoft_Gertrudis.View
{
    public partial class NuevoLibro : Form
    {
        public NuevoLibro()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            // Creamos la instancia de la ventana
            Autor ventanaNuevo = new Autor ();

            // USAR ShowDialog() es el secreto:
            // Detiene la ejecución de la principal hasta que cierres la de Nuevo Libro.
            ventanaNuevo.ShowDialog();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnRegresar_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtTitulo.Text))
            {
                DialogResult resultado = MessageBox.Show("¿Seguro que quieres salir? Se perderán los datos no guardados.",
                                                       "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    this.Close();
                }
            }
            else
            {
                this.Close(); // Si está vacío, cerramos de inmediato
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Creamos la instancia de la ventana
            Editorial ventanaNuevo = new Editorial();

            // USAR ShowDialog() es el secreto:
            // Detiene la ejecución de la principal hasta que cierres la de Nuevo Libro.
            ventanaNuevo.ShowDialog();
        }
        public void ValidarISBN(object sender, KeyPressEventArgs e)
        {
            // Solo permite números y teclas de control (borrar)
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Bloquea si es letra o símbolo
            }
        }
        public void ValidarTitulo(object sender, KeyPressEventArgs e)
        {
            // Bloqueamos solo caracteres que pueden romper una consulta SQL simple
            // como la comilla simple (') o el punto y coma (;)
            if (e.KeyChar == '\'' || e.KeyChar == ';')
            {
                e.Handled = true;
                MessageBox.Show("Caracter no permitido en el título");
            }
        }
    }
}
