﻿namespace BiblioSoft_Gertrudis.View
{
    partial class Usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Usuario));
            btnRegresar = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtNombre = new TextBox();
            txtApellidoP = new TextBox();
            txtApellidoM = new TextBox();
            txtTel = new TextBox();
            txtEmail = new TextBox();
            btnGuardar = new Button();
            label6 = new Label();
            SuspendLayout();
            // 
            // btnRegresar
            // 
            btnRegresar.FlatAppearance.BorderSize = 0;
            btnRegresar.FlatAppearance.MouseDownBackColor = Color.White;
            btnRegresar.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnRegresar.FlatStyle = FlatStyle.Flat;
            btnRegresar.Image = (Image)resources.GetObject("btnRegresar.Image");
            btnRegresar.Location = new Point(12, 12);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(55, 54);
            btnRegresar.TabIndex = 19;
            btnRegresar.UseVisualStyleBackColor = true;
            btnRegresar.Click += btnRegresar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(80, 117);
            label1.Name = "label1";
            label1.Size = new Size(78, 25);
            label1.TabIndex = 20;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(80, 169);
            label2.Name = "label2";
            label2.Size = new Size(143, 25);
            label2.TabIndex = 21;
            label2.Text = "Apellido Paterno";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(80, 231);
            label3.Name = "label3";
            label3.Size = new Size(150, 25);
            label3.TabIndex = 22;
            label3.Text = "Apellido Materno";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(80, 290);
            label4.Name = "label4";
            label4.Size = new Size(79, 25);
            label4.TabIndex = 23;
            label4.Text = "Telefono";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(80, 353);
            label5.Name = "label5";
            label5.Size = new Size(61, 25);
            label5.TabIndex = 24;
            label5.Text = "E-mail";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(164, 117);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(198, 31);
            txtNombre.TabIndex = 25;
            txtNombre.KeyPress += txtNombre_KeyPress;
            // 
            // txtApellidoP
            // 
            txtApellidoP.Location = new Point(236, 169);
            txtApellidoP.Name = "txtApellidoP";
            txtApellidoP.Size = new Size(198, 31);
            txtApellidoP.TabIndex = 26;
            txtApellidoP.TextChanged += textBox2_TextChanged;
            txtApellidoP.KeyPress += txtApellidoP_KeyPress;
            // 
            // txtApellidoM
            // 
            txtApellidoM.Location = new Point(236, 228);
            txtApellidoM.Name = "txtApellidoM";
            txtApellidoM.Size = new Size(198, 31);
            txtApellidoM.TabIndex = 27;
            txtApellidoM.KeyPress += txtApellidoM_KeyPress;
            // 
            // txtTel
            // 
            txtTel.Location = new Point(165, 290);
            txtTel.MaxLength = 15;
            txtTel.Name = "txtTel";
            txtTel.Size = new Size(198, 31);
            txtTel.TabIndex = 28;
            txtTel.KeyPress += txtTel_KeyPress;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(164, 353);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(198, 31);
            txtEmail.TabIndex = 29;
            txtEmail.Leave += txtEmail_Leave;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.Cursor = Cursors.Hand;
            btnGuardar.FlatAppearance.BorderColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.BorderSize = 0;
            btnGuardar.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.MouseOverBackColor = SystemColors.MenuHighlight;
            btnGuardar.FlatStyle = FlatStyle.Flat;
            btnGuardar.Font = new Font("Mongolian Baiti", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnGuardar.ForeColor = Color.Black;
            btnGuardar.Location = new Point(246, 417);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(126, 47);
            btnGuardar.TabIndex = 30;
            btnGuardar.Text = "GUARDAR ";
            btnGuardar.UseVisualStyleBackColor = false;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Trebuchet MS", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(165, 30);
            label6.Name = "label6";
            label6.Size = new Size(262, 36);
            label6.TabIndex = 31;
            label6.Text = "AGREGAR USUARIO";
            // 
            // Usuario
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(575, 476);
            Controls.Add(label6);
            Controls.Add(btnGuardar);
            Controls.Add(txtEmail);
            Controls.Add(txtTel);
            Controls.Add(txtApellidoM);
            Controls.Add(txtApellidoP);
            Controls.Add(txtNombre);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnRegresar);
            Name = "Usuario";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Usuario";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnRegresar;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtNombre;
        private TextBox txtApellidoP;
        private TextBox txtApellidoM;
        private TextBox txtTel;
        private TextBox txtEmail;
        private Button btnGuardar;
        private Label label6;
    }
}