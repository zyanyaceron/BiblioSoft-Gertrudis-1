﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace BiblioSoft_Gertrudis.View
{
    public partial class Usuario : Form
    {
        public Usuario()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNombre.Text))
            {
                DialogResult resultado = MessageBox.Show("¿Seguro que quieres salir? Se perderán los datos no guardados.",
                                                       "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    this.Close();
                }
            }
            else
            {
                this.Close(); // Si está vacío, cerramos de inmediato
            }
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Solo permite letras y la tecla de borrar (BackSpace)
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true; // Bloquea la tecla
                MessageBox.Show("En este campo solo se permiten letras", "Aviso");
            }
        }

        private void txtApellidoP_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Solo permite letras y la tecla de borrar (BackSpace)
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true; // Bloquea la tecla
                MessageBox.Show("En este campo solo se permiten letras", "Aviso");
            }
        }

        private void txtApellidoM_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Solo permite letras y la tecla de borrar (BackSpace)
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true; // Bloquea la tecla
                MessageBox.Show("En este campo solo se permiten letras", "Aviso");
            }
        }
        public void SoloNumerosYTelefono(KeyPressEventArgs e, string textoActual)
        {
            // 1. Permitir números, control (borrar) y espacios
            if (char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == ' ')
            {
                e.Handled = false;
            }
            // 2. Permitir el signo '+' pero SOLO si es el primer carácter
            else if (e.KeyChar == '+' && textoActual.Length == 0)
            {
                e.Handled = false;
            }
            // 3. Bloquear todo lo demás
            else
            {
                e.Handled = true;
            }
        }

        private void txtTel_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Llamamos a la función pasando el evento y el texto que ya tiene el cuadro
            SoloNumerosYTelefono(e, txtTel.Text);
        }
        public bool EsEmailValido(string email)
        {
            // Esta es la "fórmula" matemática que define un email real
            string modeloEmail = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";

            return Regex.IsMatch(email, modeloEmail);
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                if (!EsEmailValido(txtEmail.Text))
                {
                    MessageBox.Show("El formato del correo no es válido (ejemplo: usuario@dominio.com)",
                                    "Error de Formato", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtEmail.Focus(); // Regresa el cursor al cuadro para que lo corrija
                }
            }
        }
    }
}
