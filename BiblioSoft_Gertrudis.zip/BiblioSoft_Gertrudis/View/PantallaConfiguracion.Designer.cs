﻿namespace BiblioSoft_Gertrudis.View
{
    partial class PantallaConfiguracion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PantallaConfiguracion));
            panel1 = new Panel();
            btnGuardar = new Button();
            panel2 = new Panel();
            textDiasPrestamos = new TextBox();
            label3 = new Label();
            textRecargo = new TextBox();
            label2 = new Label();
            btnRegresar = new Button();
            btnPrestamos = new Button();
            btnUsuario = new Button();
            btnReportes = new Button();
            btnConfig = new Button();
            label1 = new Label();
            textBox1 = new TextBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(btnGuardar);
            panel1.Controls.Add(panel2);
            panel1.ForeColor = Color.White;
            panel1.Location = new Point(202, 99);
            panel1.Name = "panel1";
            panel1.Size = new Size(889, 548);
            panel1.TabIndex = 1;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.Cursor = Cursors.Hand;
            btnGuardar.FlatAppearance.BorderColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.BorderSize = 0;
            btnGuardar.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.MouseOverBackColor = SystemColors.MenuHighlight;
            btnGuardar.FlatStyle = FlatStyle.Flat;
            btnGuardar.Font = new Font("Mongolian Baiti", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnGuardar.ForeColor = Color.Black;
            btnGuardar.Location = new Point(577, 250);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(177, 84);
            btnGuardar.TabIndex = 17;
            btnGuardar.Text = "GUARDAR CAMBIOS";
            btnGuardar.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Controls.Add(textDiasPrestamos);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(textRecargo);
            panel2.Controls.Add(label2);
            panel2.ForeColor = Color.Black;
            panel2.Location = new Point(13, 89);
            panel2.Name = "panel2";
            panel2.Size = new Size(521, 386);
            panel2.TabIndex = 1;
            // 
            // textDiasPrestamos
            // 
            textDiasPrestamos.BackColor = Color.Silver;
            textDiasPrestamos.Location = new Point(18, 271);
            textDiasPrestamos.MaxLength = 3;
            textDiasPrestamos.Name = "textDiasPrestamos";
            textDiasPrestamos.Size = new Size(260, 31);
            textDiasPrestamos.TabIndex = 3;
            textDiasPrestamos.KeyPress += textDiasPrestamos_KeyPress;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(18, 213);
            label3.Name = "label3";
            label3.Size = new Size(422, 32);
            label3.TabIndex = 2;
            label3.Text = "DIAS DE PRESTAMOS PERMITIDOS";
            // 
            // textRecargo
            // 
            textRecargo.BackColor = Color.Silver;
            textRecargo.Location = new Point(18, 87);
            textRecargo.MaxLength = 10;
            textRecargo.Name = "textRecargo";
            textRecargo.Size = new Size(260, 31);
            textRecargo.TabIndex = 1;
            textRecargo.KeyPress += textRecargo_KeyPress;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(18, 32);
            label2.Name = "label2";
            label2.Size = new Size(248, 32);
            label2.TabIndex = 0;
            label2.Text = "REECARGO POR DIA";
            // 
            // btnRegresar
            // 
            btnRegresar.FlatAppearance.BorderSize = 0;
            btnRegresar.FlatAppearance.MouseDownBackColor = Color.White;
            btnRegresar.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnRegresar.FlatStyle = FlatStyle.Flat;
            btnRegresar.Image = (Image)resources.GetObject("btnRegresar.Image");
            btnRegresar.Location = new Point(12, 12);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(55, 54);
            btnRegresar.TabIndex = 13;
            btnRegresar.UseVisualStyleBackColor = true;
            btnRegresar.Click += btnRegresar_Click;
            // 
            // btnPrestamos
            // 
            btnPrestamos.FlatAppearance.BorderSize = 0;
            btnPrestamos.FlatAppearance.MouseDownBackColor = Color.White;
            btnPrestamos.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnPrestamos.FlatStyle = FlatStyle.Flat;
            btnPrestamos.Font = new Font("Ink Free", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPrestamos.Image = (Image)resources.GetObject("btnPrestamos.Image");
            btnPrestamos.Location = new Point(2, 110);
            btnPrestamos.Name = "btnPrestamos";
            btnPrestamos.Size = new Size(194, 82);
            btnPrestamos.TabIndex = 14;
            btnPrestamos.Text = "Prestamos";
            btnPrestamos.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnPrestamos.UseVisualStyleBackColor = true;
            btnPrestamos.Click += btnPrestamos_Click;
            // 
            // btnUsuario
            // 
            btnUsuario.FlatAppearance.BorderSize = 0;
            btnUsuario.FlatAppearance.MouseDownBackColor = Color.White;
            btnUsuario.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnUsuario.FlatStyle = FlatStyle.Flat;
            btnUsuario.Font = new Font("Ink Free", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUsuario.Image = (Image)resources.GetObject("btnUsuario.Image");
            btnUsuario.ImageAlign = ContentAlignment.MiddleLeft;
            btnUsuario.Location = new Point(2, 220);
            btnUsuario.Name = "btnUsuario";
            btnUsuario.Size = new Size(183, 86);
            btnUsuario.TabIndex = 15;
            btnUsuario.Text = "Usuario";
            btnUsuario.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnUsuario.UseVisualStyleBackColor = true;
            btnUsuario.Click += btnUsuario_Click;
            // 
            // btnReportes
            // 
            btnReportes.FlatAppearance.BorderSize = 0;
            btnReportes.FlatAppearance.MouseDownBackColor = Color.White;
            btnReportes.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Ink Free", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReportes.Image = (Image)resources.GetObject("btnReportes.Image");
            btnReportes.ImageAlign = ContentAlignment.MiddleLeft;
            btnReportes.Location = new Point(2, 339);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(194, 94);
            btnReportes.TabIndex = 16;
            btnReportes.Text = "Reportes";
            btnReportes.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnReportes.UseVisualStyleBackColor = true;
            btnReportes.Click += btnReportes_Click;
            // 
            // btnConfig
            // 
            btnConfig.BackColor = Color.White;
            btnConfig.Enabled = false;
            btnConfig.FlatAppearance.BorderSize = 0;
            btnConfig.FlatAppearance.MouseDownBackColor = Color.White;
            btnConfig.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnConfig.FlatStyle = FlatStyle.Flat;
            btnConfig.Font = new Font("Ink Free", 7.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnConfig.Image = (Image)resources.GetObject("btnConfig.Image");
            btnConfig.ImageAlign = ContentAlignment.MiddleLeft;
            btnConfig.Location = new Point(2, 474);
            btnConfig.Name = "btnConfig";
            btnConfig.Size = new Size(194, 78);
            btnConfig.TabIndex = 17;
            btnConfig.Text = "Configuracion";
            btnConfig.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnConfig.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(348, 30);
            label1.TabIndex = 0;
            label1.Text = "MONTO DE RECARGO POR DIA";
            label1.Click += label1_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(357, 3);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(150, 31);
            textBox1.TabIndex = 1;
            // 
            // PantallaConfiguracion
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(1103, 659);
            Controls.Add(btnConfig);
            Controls.Add(btnReportes);
            Controls.Add(btnUsuario);
            Controls.Add(btnPrestamos);
            Controls.Add(btnRegresar);
            Controls.Add(panel1);
            Name = "PantallaConfiguracion";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "PantallaConfiguracion";
            FormClosed += PantallaConfiguracion_FormClosed;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button btnRegresar;
        private Button btnPrestamos;
        private Button btnUsuario;
        private Button btnReportes;
        private Button btnConfig;
        private Label label1;
        private Panel panel2;
        private TextBox textBox1;
        private TextBox textDiasPrestamos;
        private Label label3;
        private TextBox textRecargo;
        private Label label2;
        private Button btnGuardar;
    }
}