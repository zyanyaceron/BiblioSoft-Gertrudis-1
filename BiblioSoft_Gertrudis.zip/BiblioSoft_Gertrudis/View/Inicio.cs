﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace BiblioSoft_Gertrudis.View
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)

        {
            Panel pnl = (Panel)sender;
            int radius = 30; // Ajusta qué tan redondo lo quieres aquí

            // Usamos 'using' para que la memoria se limpie sola y no se trabe
            using (GraphicsPath path = new GraphicsPath())
            {
                path.StartFigure();
                // Arriba izquierda
                path.AddArc(new Rectangle(0, 0, radius, radius), 180, 90);
                // Arriba derecha
                path.AddArc(new Rectangle(pnl.Width - radius, 0, radius, radius), 270, 90);
                // Abajo derecha
                path.AddArc(new Rectangle(pnl.Width - radius, pnl.Height - radius, radius, radius), 0, 90);
                // Abajo izquierda
                path.AddArc(new Rectangle(0, pnl.Height - radius, radius, radius), 90, 90);
                path.CloseFigure();

                // Aplicamos la forma al panel
                pnl.Region = new Region(path);

                // Suavizamos el borde para que no se vea "mordido"
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            }

        }

        private void panel1_Resize(object sender, EventArgs e)
        {
            panel1.Invalidate(); // Esto obliga al panel a redibujarse al cambiar de tamaño
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textISBN_Enter(object sender, EventArgs e)
        {
            if (textISBN.Text == "Buscar por ISBN")
            {
                textISBN.Text = "";
                textISBN.ForeColor = Color.Black;
            }
        }

        private void textISBN_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textISBN.Text))
            {
                textISBN.Text = "Buscar por ISBN"; // Ponemos la sugerencia otra vez
                textISBN.ForeColor = Color.White; // Regresamos al color gris
            }
        }

        private void Inicio_Load(object sender, EventArgs e)
        {
            this.ActiveControl = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaUsuario pantallaUsuario = new PantallaUsuario();

            // Mostramos la nueva
            pantallaUsuario.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaReportes pantallaReportes = new PantallaReportes();

            // Mostramos la nueva
            pantallaReportes.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaConfiguracion PantallaConfiguracion = new PantallaConfiguracion();

            // Mostramos la nueva
            PantallaConfiguracion.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textISBN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '-'))
            {
                e.Handled = true; // Esto "bloquea" la tecla si no es lo que queremos
            }
        }

        private void textISBN_Validating(object sender, CancelEventArgs e)
        {
            string texto = textISBN.Text.Replace("-", ""); // Quitamos guiones para contar

            // Si el usuario ya borró el placeholder y escribió algo
            if (textISBN.Text != "Buscar por ISBN" && !string.IsNullOrWhiteSpace(texto))
            {
                if (texto.Length != 10 && texto.Length != 13)
                {
                    MessageBox.Show("El ISBN debe tener 10 o 13 dígitos.", "Error de formato",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Opcional: limpiar el campo o regresar el foco
                    // e.Cancel = true; 
                }
            }
        }

        private void btnPrestamos_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaPrestamos pantallaPrestamos = new PantallaPrestamos();

            // Mostramos la nueva
            pantallaPrestamos.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void textBuscarISBN_Click(object sender, EventArgs e)
        {
            // Creamos la instancia de la ventana
            NuevoLibro ventanaNuevo = new NuevoLibro();

            // USAR ShowDialog() es el secreto:
            // Detiene la ejecución de la principal hasta que cierres la de Nuevo Libro.
            ventanaNuevo.ShowDialog();
        }
    }
}
