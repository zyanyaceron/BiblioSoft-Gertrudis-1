﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BiblioSoft_Gertrudis.View
{
    public partial class PantallaPrestamos : Form
    {
        public PantallaPrestamos()
        {
            InitializeComponent();
        }

        private void PantallaPrestamos_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Esto mata TODOS los procesos de BiblioSoft, incluyendo la ventana invisible de Inicio
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaReportes pantallaReportes = new PantallaReportes();

            // Mostramos la nueva
            pantallaReportes.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void btnPrestamos_Click(object sender, EventArgs e)
        {

        }

        private void textDNI_TextChanged(object sender, EventArgs e)
        {
            // Solo si no es el placeholder
            if (textDNI.Text != "Ingrese DNI del usuario")
            {
                textDNI.Text = textDNI.Text.ToUpper();
                textDNI.SelectionStart = textDNI.Text.Length; // Mantiene el cursor al final
            }
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Form inicio = Application.OpenForms["Inicio"];

            if (inicio != null)
            {
                inicio.Show(); // La volvemos a mostrar

                // IMPORTANTE: Aquí NO uses Application.Exit(), 
                // solo cierra esta ventana de Prestamos para volver a la anterior.
                this.Dispose();
            }
        }

        private void textDNI_Enter(object sender, EventArgs e)
        {
            if (textDNI.Text == "Ingrese DNI o ISBN del libro")
            {
                textDNI.Text = "";
                textDNI.ForeColor = Color.Black; // Color de escritura normal
            }
        }

        private void textDNI_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textDNI.Text))
            {
                textDNI.Text = "Ingrese DNI del usuario o ISBN del libro";
                textDNI.ForeColor = Color.Gray;
            }
        }

        private void textDNI_KeyPress(object sender, KeyPressEventArgs e)
        {
            // char.IsLetterOrDigit permite letras (A-Z) y números (0-9)
            if (!char.IsLetterOrDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != '-')
            {
                e.Handled = true; // Bloquea puntos, espacios y otros símbolos
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaUsuario pantallaUsuario = new PantallaUsuario();

            // Mostramos la nueva
            pantallaUsuario.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void textDNI_Validating(object sender, CancelEventArgs e)
        {
            string entrada = textDNI.Text.Trim();

            // Si no es el placeholder y no está vacío
            if (entrada != "Buscar por ISBN o Clave" && !string.IsNullOrWhiteSpace(entrada))
            {
                int largo = entrada.Length;

                // Validamos que cumpla con alguna de las tres longitudes permitidas
                if (largo != 10 && largo != 13 && largo != 18)
                {
                    MessageBox.Show("El código no es válido.\n\n- ISBN: 10 o 13 dígitos.\n- Clave de Elector: 18 caracteres.",
                                    "Error de Formato", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Opcional: e.Cancel = true; // No deja salir del cuadro hasta que corrija
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaConfiguracion PantallaConfiguracion = new PantallaConfiguracion();

            // Mostramos la nueva
            PantallaConfiguracion.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void btnPrestar_Click(object sender, EventArgs e)
        {
            // Creamos la instancia de la ventana
            Prestamos ventanaNuevo = new Prestamos();

            // USAR ShowDialog() es el secreto:
            // Detiene la ejecución de la principal hasta que cierres la de Nuevo Libro.
            ventanaNuevo.ShowDialog();
        }
    }
}
