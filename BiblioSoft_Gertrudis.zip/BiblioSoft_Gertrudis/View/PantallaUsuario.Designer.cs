﻿namespace BiblioSoft_Gertrudis.View
{
    partial class PantallaUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PantallaUsuario));
            panel1 = new Panel();
            btnPrestamos = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            btnRegresar = new Button();
            textDNI = new TextBox();
            button1 = new Button();
            txtNuevoUsuario = new Button();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.ForeColor = Color.Chocolate;
            panel1.Location = new Point(202, 99);
            panel1.Name = "panel1";
            panel1.Size = new Size(889, 548);
            panel1.TabIndex = 1;
            // 
            // btnPrestamos
            // 
            btnPrestamos.FlatAppearance.BorderSize = 0;
            btnPrestamos.FlatAppearance.MouseDownBackColor = Color.White;
            btnPrestamos.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnPrestamos.FlatStyle = FlatStyle.Flat;
            btnPrestamos.Font = new Font("Ink Free", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPrestamos.Image = (Image)resources.GetObject("btnPrestamos.Image");
            btnPrestamos.Location = new Point(2, 99);
            btnPrestamos.Name = "btnPrestamos";
            btnPrestamos.Size = new Size(194, 82);
            btnPrestamos.TabIndex = 5;
            btnPrestamos.Text = "Prestamos";
            btnPrestamos.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnPrestamos.UseVisualStyleBackColor = true;
            btnPrestamos.Click += btnPrestamos_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.HighlightText;
            button3.Enabled = false;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseDownBackColor = Color.White;
            button3.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Ink Free", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(2, 220);
            button3.Name = "button3";
            button3.Size = new Size(194, 86);
            button3.TabIndex = 6;
            button3.Text = "Usuario";
            button3.TextImageRelation = TextImageRelation.ImageBeforeText;
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.MouseDownBackColor = Color.White;
            button4.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Ink Free", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Image = (Image)resources.GetObject("button4.Image");
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.Location = new Point(2, 338);
            button4.Name = "button4";
            button4.Size = new Size(194, 94);
            button4.TabIndex = 7;
            button4.Text = "Reportes";
            button4.TextImageRelation = TextImageRelation.ImageBeforeText;
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.MouseDownBackColor = Color.White;
            button5.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Ink Free", 7.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.ImageAlign = ContentAlignment.MiddleLeft;
            button5.Location = new Point(2, 468);
            button5.Name = "button5";
            button5.Size = new Size(194, 78);
            button5.TabIndex = 8;
            button5.Text = "Configuracion";
            button5.TextImageRelation = TextImageRelation.ImageBeforeText;
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // btnRegresar
            // 
            btnRegresar.FlatAppearance.BorderSize = 0;
            btnRegresar.FlatAppearance.MouseDownBackColor = Color.White;
            btnRegresar.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnRegresar.FlatStyle = FlatStyle.Flat;
            btnRegresar.Image = (Image)resources.GetObject("btnRegresar.Image");
            btnRegresar.Location = new Point(12, 12);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(55, 54);
            btnRegresar.TabIndex = 12;
            btnRegresar.UseVisualStyleBackColor = true;
            btnRegresar.Click += btnRegresar_Click;
            // 
            // textDNI
            // 
            textDNI.BackColor = Color.Silver;
            textDNI.BorderStyle = BorderStyle.None;
            textDNI.CharacterCasing = CharacterCasing.Upper;
            textDNI.Font = new Font("Georgia", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textDNI.ForeColor = Color.White;
            textDNI.Location = new Point(202, 38);
            textDNI.MaxLength = 18;
            textDNI.Name = "textDNI";
            textDNI.Size = new Size(600, 28);
            textDNI.TabIndex = 13;
            textDNI.Text = "INGRESE DNI";
            textDNI.Enter += textDNI_Enter;
            textDNI.KeyPress += textDNI_KeyPress;
            textDNI.Leave += textDNI_Leave;
            // 
            // button1
            // 
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.White;
            button1.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.Location = new Point(808, 26);
            button1.Name = "button1";
            button1.Size = new Size(55, 54);
            button1.TabIndex = 14;
            button1.UseVisualStyleBackColor = true;
            // 
            // txtNuevoUsuario
            // 
            txtNuevoUsuario.BackColor = Color.FromArgb(192, 255, 192);
            txtNuevoUsuario.Cursor = Cursors.Hand;
            txtNuevoUsuario.FlatAppearance.BorderColor = Color.FromArgb(192, 255, 192);
            txtNuevoUsuario.FlatAppearance.BorderSize = 0;
            txtNuevoUsuario.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 255, 192);
            txtNuevoUsuario.FlatAppearance.MouseOverBackColor = Color.White;
            txtNuevoUsuario.FlatStyle = FlatStyle.Flat;
            txtNuevoUsuario.Font = new Font("Mongolian Baiti", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            txtNuevoUsuario.ForeColor = Color.Black;
            txtNuevoUsuario.Location = new Point(904, 31);
            txtNuevoUsuario.Name = "txtNuevoUsuario";
            txtNuevoUsuario.Size = new Size(177, 35);
            txtNuevoUsuario.TabIndex = 16;
            txtNuevoUsuario.Text = "NUEVO USUARIO";
            txtNuevoUsuario.UseVisualStyleBackColor = false;
            txtNuevoUsuario.Click += textBuscarISBN_Click;
            // 
            // PantallaUsuario
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(1103, 659);
            Controls.Add(txtNuevoUsuario);
            Controls.Add(button1);
            Controls.Add(textDNI);
            Controls.Add(btnRegresar);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(btnPrestamos);
            Controls.Add(panel1);
            Name = "PantallaUsuario";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "PantallaUsuario";
            FormClosed += PantallaUsuario_FormClosed;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button btnPrestamos;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button btnRegresar;
        private TextBox textDNI;
        private Button button1;
        private Button txtNuevoUsuario;
    }
}