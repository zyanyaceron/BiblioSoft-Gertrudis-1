﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BiblioSoft_Gertrudis.View
{
    public partial class PantallaUsuario : Form
    {
        public PantallaUsuario()
        {
            InitializeComponent();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Form inicio = Application.OpenForms["Inicio"];

            if (inicio != null)
            {
                inicio.Show(); // La volvemos a mostrar

                // IMPORTANTE: Aquí NO uses Application.Exit(), 
                // solo cierra esta ventana de Prestamos para volver a la anterior.
                this.Dispose();
            }
        }

        private void textDNI_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textDNI.Text))
            {
                textDNI.Text = "INGRESE DNIKKKK";
                textDNI.ForeColor = Color.Gray; // Color de marca de agua
            }
        }

        private void textDNI_Enter(object sender, EventArgs e)
        {
            if (textDNI.Text.Trim().ToUpper() == "INGRESE DNI")
            {
                textDNI.Text = "";
                textDNI.ForeColor = Color.Black; // Cambia a color de escritura normal
            }
        }

        private void btnPrestamos_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaPrestamos pantallaPrestamos = new PantallaPrestamos();

            // Mostramos la nueva
            pantallaPrestamos.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void textDNI_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetterOrDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Bloquea guiones, puntos, comas y espacios
            }
        }

        private void PantallaUsuario_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Mata el proceso de BiblioSoft por completo al cerrar esta ventana
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaReportes pantallaReportes = new PantallaReportes();

            // Mostramos la nueva
            pantallaReportes.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaConfiguracion PantallaConfiguracion = new PantallaConfiguracion();

            // Mostramos la nueva
            PantallaConfiguracion.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void textBuscarISBN_Click(object sender, EventArgs e)
        {
            // Creamos la instancia de la ventana
            Usuario ventanaNuevo = new Usuario();

            // USAR ShowDialog() es el secreto:
            // Detiene la ejecución de la principal hasta que cierres la de Nuevo Libro.
            ventanaNuevo.ShowDialog();
        }
    }
}
