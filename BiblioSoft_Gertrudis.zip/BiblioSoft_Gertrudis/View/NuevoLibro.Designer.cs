﻿namespace BiblioSoft_Gertrudis.View
{
    partial class NuevoLibro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NuevoLibro));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            cmbEstadoDisponibilidad = new ComboBox();
            cmbCategoria = new ComboBox();
            cmbEstadoFisico = new ComboBox();
            cmbEditorial = new ComboBox();
            maskedTextBox1 = new MaskedTextBox();
            txtTitulo = new MaskedTextBox();
            dateTimePicker1 = new DateTimePicker();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            comboBox1 = new ComboBox();
            label8 = new Label();
            btnAgregarAutor = new Button();
            button1 = new Button();
            btnRegresar = new Button();
            btnGuardar = new Button();
            label9 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(59, 80);
            label1.Name = "label1";
            label1.Size = new Size(50, 25);
            label1.TabIndex = 0;
            label1.Text = "ISBN";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(59, 119);
            label2.Name = "label2";
            label2.Size = new Size(56, 25);
            label2.TabIndex = 1;
            label2.Text = "Titulo";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(59, 166);
            label3.Name = "label3";
            label3.Size = new Size(164, 25);
            label3.TabIndex = 2;
            label3.Text = "Año de Publicacion";
            // 
            // cmbEstadoDisponibilidad
            // 
            cmbEstadoDisponibilidad.FormattingEnabled = true;
            cmbEstadoDisponibilidad.Location = new Point(280, 269);
            cmbEstadoDisponibilidad.Name = "cmbEstadoDisponibilidad";
            cmbEstadoDisponibilidad.Size = new Size(182, 33);
            cmbEstadoDisponibilidad.TabIndex = 3;
            // 
            // cmbCategoria
            // 
            cmbCategoria.FormattingEnabled = true;
            cmbCategoria.Location = new Point(153, 373);
            cmbCategoria.Name = "cmbCategoria";
            cmbCategoria.Size = new Size(182, 33);
            cmbCategoria.TabIndex = 4;
            // 
            // cmbEstadoFisico
            // 
            cmbEstadoFisico.FormattingEnabled = true;
            cmbEstadoFisico.Location = new Point(229, 219);
            cmbEstadoFisico.Name = "cmbEstadoFisico";
            cmbEstadoFisico.Size = new Size(182, 33);
            cmbEstadoFisico.TabIndex = 5;
            // 
            // cmbEditorial
            // 
            cmbEditorial.FormattingEnabled = true;
            cmbEditorial.Location = new Point(141, 323);
            cmbEditorial.Name = "cmbEditorial";
            cmbEditorial.Size = new Size(182, 33);
            cmbEditorial.TabIndex = 6;
            cmbEditorial.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.Location = new Point(115, 74);
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(430, 31);
            maskedTextBox1.TabIndex = 7;
            maskedTextBox1.MaskInputRejected += maskedTextBox1_MaskInputRejected;
            maskedTextBox1.KeyPress += ValidarISBN;
            // 
            // txtTitulo
            // 
            txtTitulo.Location = new Point(115, 116);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(430, 31);
            txtTitulo.TabIndex = 8;
            txtTitulo.KeyPress += ValidarTitulo;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.CustomFormat = "yyyy";
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.Location = new Point(229, 166);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(110, 31);
            dateTimePicker1.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(59, 222);
            label4.Name = "label4";
            label4.Size = new Size(115, 25);
            label4.TabIndex = 10;
            label4.Text = "Estado Fisico";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(59, 273);
            label5.Name = "label5";
            label5.Size = new Size(211, 25);
            label5.TabIndex = 11;
            label5.Text = "Estado de Disponibilidad";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(59, 326);
            label6.Name = "label6";
            label6.Size = new Size(76, 25);
            label6.TabIndex = 12;
            label6.Text = "Editorial";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(59, 381);
            label7.Name = "label7";
            label7.Size = new Size(88, 25);
            label7.TabIndex = 13;
            label7.Text = "Categoria";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(153, 428);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(182, 33);
            comboBox1.TabIndex = 14;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(59, 436);
            label8.Name = "label8";
            label8.Size = new Size(57, 25);
            label8.TabIndex = 15;
            label8.Text = "Autor";
            // 
            // btnAgregarAutor
            // 
            btnAgregarAutor.FlatAppearance.BorderSize = 0;
            btnAgregarAutor.FlatAppearance.MouseDownBackColor = Color.White;
            btnAgregarAutor.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnAgregarAutor.FlatStyle = FlatStyle.Flat;
            btnAgregarAutor.Image = (Image)resources.GetObject("btnAgregarAutor.Image");
            btnAgregarAutor.Location = new Point(341, 421);
            btnAgregarAutor.Name = "btnAgregarAutor";
            btnAgregarAutor.Size = new Size(55, 54);
            btnAgregarAutor.TabIndex = 16;
            btnAgregarAutor.UseVisualStyleBackColor = true;
            btnAgregarAutor.Click += btnRegresar_Click;
            // 
            // button1
            // 
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.White;
            button1.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.Location = new Point(329, 313);
            button1.Name = "button1";
            button1.Size = new Size(55, 54);
            button1.TabIndex = 17;
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnRegresar
            // 
            btnRegresar.FlatAppearance.BorderSize = 0;
            btnRegresar.FlatAppearance.MouseDownBackColor = Color.White;
            btnRegresar.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnRegresar.FlatStyle = FlatStyle.Flat;
            btnRegresar.Image = (Image)resources.GetObject("btnRegresar.Image");
            btnRegresar.Location = new Point(12, 12);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(55, 54);
            btnRegresar.TabIndex = 18;
            btnRegresar.UseVisualStyleBackColor = true;
            btnRegresar.Click += btnRegresar_Click_1;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.Cursor = Cursors.Hand;
            btnGuardar.FlatAppearance.BorderColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.BorderSize = 0;
            btnGuardar.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.MouseOverBackColor = SystemColors.MenuHighlight;
            btnGuardar.FlatStyle = FlatStyle.Flat;
            btnGuardar.Font = new Font("Mongolian Baiti", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnGuardar.ForeColor = Color.Black;
            btnGuardar.Location = new Point(336, 481);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(126, 47);
            btnGuardar.TabIndex = 19;
            btnGuardar.Text = "GUARDAR ";
            btnGuardar.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Trebuchet MS", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(280, 12);
            label9.Name = "label9";
            label9.Size = new Size(224, 36);
            label9.TabIndex = 22;
            label9.Text = "AGREGAR LIBRO";
            // 
            // NuevoLibro
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(828, 544);
            Controls.Add(label9);
            Controls.Add(btnGuardar);
            Controls.Add(btnRegresar);
            Controls.Add(button1);
            Controls.Add(btnAgregarAutor);
            Controls.Add(label8);
            Controls.Add(comboBox1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(dateTimePicker1);
            Controls.Add(txtTitulo);
            Controls.Add(maskedTextBox1);
            Controls.Add(cmbEditorial);
            Controls.Add(cmbEstadoFisico);
            Controls.Add(cmbCategoria);
            Controls.Add(cmbEstadoDisponibilidad);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "NuevoLibro";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NuevoLibro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox cmbEstadoDisponibilidad;
        private ComboBox cmbCategoria;
        private ComboBox cmbEstadoFisico;
        private ComboBox cmbEditorial;
        private MaskedTextBox maskedTextBox1;
        private MaskedTextBox txtTitulo;
        private DateTimePicker dateTimePicker1;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private ComboBox comboBox1;
        private Label label8;
        private Button btnAgregarAutor;
        private Button button1;
        private Button btnRegresar;
        private Button btnGuardar;
        private Label label9;
    }
}