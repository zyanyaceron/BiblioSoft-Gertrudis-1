﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BiblioSoft_Gertrudis.View
{
    public partial class PantallaConfiguracion : Form
    {
        public PantallaConfiguracion()
        {
            InitializeComponent();
        }

        private void PantallaConfiguracion_FormClosed(object sender, FormClosedEventArgs e)
        {

            // Mata el proceso de BiblioSoft por completo al cerrar esta ventana
            Application.Exit();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Form inicio = Application.OpenForms["Inicio"];

            if (inicio != null)
            {
                inicio.Show(); // La volvemos a mostrar

                // IMPORTANTE: Aquí NO uses Application.Exit(), 
                // solo cierra esta ventana de Prestamos para volver a la anterior.
                this.Dispose();
            }
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaReportes PantallaReportes = new PantallaReportes();

            // Mostramos la nueva
            PantallaReportes.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void btnUsuario_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaUsuario pantallaUsuario = new PantallaUsuario();

            // Mostramos la nueva
            pantallaUsuario.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void btnPrestamos_Click(object sender, EventArgs e)
        {
            // Creamos la ventana
            PantallaPrestamos pantallaPrestamos = new PantallaPrestamos();

            // Mostramos la nueva
            pantallaPrestamos.Show();

            // OCULTAMOS la actual (Inicio)
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textRecargo_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Solo permite números, el punto decimal y la tecla de borrar (BackSpace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // Solo permite UN punto decimal en todo el texto
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }

            // Si ya hay un punto, solo deja escribir 2 números después de él
            if (char.IsDigit(e.KeyChar) && (sender as TextBox).Text.Contains("."))
            {
                string[] partes = (sender as TextBox).Text.Split('.');
                if (partes.Length > 1 && partes[1].Length >= 2)
                {
                    // Si el cursor está después del punto, bloqueamos la entrada
                    if ((sender as TextBox).SelectionStart > (sender as TextBox).Text.IndexOf('.'))
                    {
                        e.Handled = true;
                    }
                }
            }
        }

        private void textDiasPrestamos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Bloquea letras, puntos, comas y espacios
            }
        }
    }
}
