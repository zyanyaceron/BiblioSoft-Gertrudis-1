﻿namespace BiblioSoft_Gertrudis.View
{
    partial class Prestamos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Prestamos));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            dateTimePicker1 = new DateTimePicker();
            dateTimePicker2 = new DateTimePicker();
            txtISBN = new TextBox();
            textBox2 = new TextBox();
            btnGuardar = new Button();
            btnRegresar = new Button();
            label6 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(68, 73);
            label1.Name = "label1";
            label1.Size = new Size(323, 25);
            label1.TabIndex = 0;
            label1.Text = "ESCRIBE EL ISBN DEL LIBRO A PRESTAR";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(68, 139);
            label2.Name = "label2";
            label2.Size = new Size(302, 25);
            label2.TabIndex = 1;
            label2.Text = "ESCRIBE EL INE O DNI DEL USUARIO";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(68, 207);
            label3.Name = "label3";
            label3.Size = new Size(196, 25);
            label3.TabIndex = 2;
            label3.Text = "FECHA DEL PRESTAMO";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(68, 273);
            label4.Name = "label4";
            label4.Size = new Size(213, 25);
            label4.TabIndex = 3;
            label4.Text = "FECHA DE DEVOLUCION ";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(300, 207);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(300, 31);
            dateTimePicker1.TabIndex = 4;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(300, 273);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(300, 31);
            dateTimePicker2.TabIndex = 5;
            // 
            // txtISBN
            // 
            txtISBN.Location = new Point(402, 71);
            txtISBN.MaxLength = 17;
            txtISBN.Name = "txtISBN";
            txtISBN.Size = new Size(302, 31);
            txtISBN.TabIndex = 6;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(402, 139);
            textBox2.MaxLength = 18;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(302, 31);
            textBox2.TabIndex = 7;
            textBox2.KeyPress += ValidarINE;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.Cursor = Cursors.Hand;
            btnGuardar.FlatAppearance.BorderColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.BorderSize = 0;
            btnGuardar.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.MouseOverBackColor = SystemColors.MenuHighlight;
            btnGuardar.FlatStyle = FlatStyle.Flat;
            btnGuardar.Font = new Font("Mongolian Baiti", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnGuardar.ForeColor = Color.Black;
            btnGuardar.Location = new Point(279, 362);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(126, 47);
            btnGuardar.TabIndex = 31;
            btnGuardar.Text = "GUARDAR ";
            btnGuardar.UseVisualStyleBackColor = false;
            // 
            // btnRegresar
            // 
            btnRegresar.FlatAppearance.BorderSize = 0;
            btnRegresar.FlatAppearance.MouseDownBackColor = Color.White;
            btnRegresar.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnRegresar.FlatStyle = FlatStyle.Flat;
            btnRegresar.Image = (Image)resources.GetObject("btnRegresar.Image");
            btnRegresar.Location = new Point(12, 12);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(55, 54);
            btnRegresar.TabIndex = 32;
            btnRegresar.UseVisualStyleBackColor = true;
            btnRegresar.Click += btnRegresar_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Trebuchet MS", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(300, 18);
            label6.Name = "label6";
            label6.Size = new Size(127, 36);
            label6.TabIndex = 33;
            label6.Text = "PRESTAR";
            // 
            // Prestamos
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(715, 450);
            Controls.Add(label6);
            Controls.Add(btnRegresar);
            Controls.Add(btnGuardar);
            Controls.Add(textBox2);
            Controls.Add(txtISBN);
            Controls.Add(dateTimePicker2);
            Controls.Add(dateTimePicker1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Prestamos";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Prestamos";
            Load += Prestamos_Load;
            KeyPress += ValidarISBN;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private TextBox txtISBN;
        private TextBox textBox2;
        private Button btnGuardar;
        private Button btnRegresar;
        private Label label6;
    }
}