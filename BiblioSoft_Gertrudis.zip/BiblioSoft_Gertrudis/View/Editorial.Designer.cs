﻿namespace BiblioSoft_Gertrudis.View
{
    partial class Editorial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Editorial));
            label1 = new Label();
            label2 = new Label();
            txtNombre = new TextBox();
            comboBox1 = new ComboBox();
            btnRegresar = new Button();
            label3 = new Label();
            btnGuardar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(89, 73);
            label1.Name = "label1";
            label1.Size = new Size(78, 25);
            label1.TabIndex = 1;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(89, 143);
            label2.Name = "label2";
            label2.Size = new Size(42, 25);
            label2.TabIndex = 2;
            label2.Text = "Pais";
            label2.Click += label2_Click_1;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(173, 75);
            txtNombre.MaxLength = 50;
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(182, 31);
            txtNombre.TabIndex = 3;
            txtNombre.KeyPress += txtNombre_KeyPress;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(173, 135);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(182, 33);
            comboBox1.TabIndex = 4;
            // 
            // btnRegresar
            // 
            btnRegresar.FlatAppearance.BorderSize = 0;
            btnRegresar.FlatAppearance.MouseDownBackColor = Color.White;
            btnRegresar.FlatAppearance.MouseOverBackColor = Color.WhiteSmoke;
            btnRegresar.FlatStyle = FlatStyle.Flat;
            btnRegresar.Image = (Image)resources.GetObject("btnRegresar.Image");
            btnRegresar.Location = new Point(12, 12);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(55, 54);
            btnRegresar.TabIndex = 19;
            btnRegresar.UseVisualStyleBackColor = true;
            btnRegresar.Click += btnRegresar_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Trebuchet MS", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(120, 18);
            label3.Name = "label3";
            label3.Size = new Size(282, 36);
            label3.TabIndex = 20;
            label3.Text = "AGREGAR EDITORIAL";
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.Cursor = Cursors.Hand;
            btnGuardar.FlatAppearance.BorderColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.BorderSize = 0;
            btnGuardar.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 255, 192);
            btnGuardar.FlatAppearance.MouseOverBackColor = SystemColors.MenuHighlight;
            btnGuardar.FlatStyle = FlatStyle.Flat;
            btnGuardar.Font = new Font("Mongolian Baiti", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnGuardar.ForeColor = Color.Black;
            btnGuardar.Location = new Point(192, 211);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(126, 47);
            btnGuardar.TabIndex = 21;
            btnGuardar.Text = "GUARDAR ";
            btnGuardar.UseVisualStyleBackColor = false;
            // 
            // Editorial
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(459, 270);
            Controls.Add(btnGuardar);
            Controls.Add(label3);
            Controls.Add(btnRegresar);
            Controls.Add(comboBox1);
            Controls.Add(txtNombre);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Editorial";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Editorial";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtNombre;
        private ComboBox comboBox1;
        private Button btnRegresar;
        private Label label3;
        private Button btnGuardar;
    }
}