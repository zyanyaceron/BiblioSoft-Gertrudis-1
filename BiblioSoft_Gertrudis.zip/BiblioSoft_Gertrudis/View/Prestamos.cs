﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BiblioSoft_Gertrudis.View
{
    public partial class Prestamos : Form
    {
        public Prestamos()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Prestamos_Load(object sender, EventArgs e)
        {

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtISBN.Text))
            {
                DialogResult resultado = MessageBox.Show("¿Seguro que quieres salir? Se perderán los datos no guardados.",
                                                       "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    this.Close();
                }
            }
            else
            {
                this.Close(); // Si está vacío, cerramos de inmediato
            }
        
    }
        public void ValidarISBN(object sender, KeyPressEventArgs e)
        {
            // Solo permite números y teclas de control (borrar)
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Bloquea si es letra o símbolo
            }
        }
        public void ValidarINE(object sender, KeyPressEventArgs e)
        {
            // Solo permite letras, números y la tecla de borrar (Control)
            if (!char.IsLetterOrDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Bloquea símbolos como @, #, $, etc.
            }
        }
    }
}
